public class Digestiva extends EnfermedadCongenita {
    public Digestiva(String nombre, Integer newAttr) {
        super(nombre, newAttr);
    }
}
