public class Responsable {
    private String email;
    private Persona persona;

    public Responsable(String email, Persona persona) {
        this.email = email;
        this.persona = persona;
    }

    public String getEmail() {
        return email;
    }

}
