public class Compartido extends HospedajeRol{

    public Compartido(Boolean bañoCompartido, String tipo) {
        super(bañoCompartido, tipo);
    }
    
}
