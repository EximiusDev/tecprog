package objetos2016;

public class Gato {

}
