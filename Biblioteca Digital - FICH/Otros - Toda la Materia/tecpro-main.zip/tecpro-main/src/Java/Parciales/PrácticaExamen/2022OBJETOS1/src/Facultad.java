public class Facultad {

    private String sigla;

    public void mostrarDatos() {
        System.out.print("SIGLA : " + sigla);
    }

}
