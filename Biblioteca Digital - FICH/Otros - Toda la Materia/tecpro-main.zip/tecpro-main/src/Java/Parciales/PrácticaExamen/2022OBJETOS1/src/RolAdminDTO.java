public class RolAdminDTO {
    private String clave;


    public Boolean esComensal(){
        return false;
    }
}
