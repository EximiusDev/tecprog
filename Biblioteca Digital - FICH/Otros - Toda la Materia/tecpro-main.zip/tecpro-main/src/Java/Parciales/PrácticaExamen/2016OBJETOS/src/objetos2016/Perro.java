package objetos2016;

public class Perro {

}
