public class Catedra {
    private String nombre;

    public Catedra(String nombre) {
        this.nombre = nombre;
    }
}
