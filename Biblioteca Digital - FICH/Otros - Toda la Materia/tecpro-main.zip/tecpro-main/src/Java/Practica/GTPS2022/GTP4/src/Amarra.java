public class Amarra {
    private Short posicion;

    public Amarra(Short posicion) {
        this.posicion = posicion;
    }
    
    public Short obtenerPosicion(){
        return this.posicion;
    }
    
}
