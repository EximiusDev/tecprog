import java.util.Calendar;

public class Alquiler {
    private Cliente cliente;
    private Calendar reserva;
    private Calendar hasta;

    
    
}
