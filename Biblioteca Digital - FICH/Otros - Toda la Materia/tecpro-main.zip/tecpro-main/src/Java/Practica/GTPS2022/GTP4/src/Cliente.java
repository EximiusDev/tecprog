public class Cliente {
    private Integer dni;
    
}
