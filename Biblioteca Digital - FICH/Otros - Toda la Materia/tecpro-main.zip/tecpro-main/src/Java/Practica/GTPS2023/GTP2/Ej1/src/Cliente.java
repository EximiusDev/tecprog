package Java.GTPS2023.GTP2.Ej1.src;

public class Cliente {
    private Integer nroCliete;

    public Cliente(Integer nroCliete) {
        this.nroCliete = nroCliete;
    }
    
}
