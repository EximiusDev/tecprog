# TecPro
Repository to add the excersices done on Programming Technologies from my college
