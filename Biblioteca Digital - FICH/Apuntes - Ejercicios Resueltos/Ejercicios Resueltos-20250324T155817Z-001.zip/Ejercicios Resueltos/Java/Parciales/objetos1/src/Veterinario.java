public class Veterinario {
    
}
