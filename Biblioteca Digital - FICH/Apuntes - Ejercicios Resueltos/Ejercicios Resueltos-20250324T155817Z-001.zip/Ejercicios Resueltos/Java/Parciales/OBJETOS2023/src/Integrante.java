public class Integrante {
    private String parentezco;
    private Persona persona;

    public Integrante(String parentezco, Persona persona) {
        this.parentezco = parentezco;
        this.persona = persona;
    }

    public String getParentezco() {
        return parentezco;
    }

}
