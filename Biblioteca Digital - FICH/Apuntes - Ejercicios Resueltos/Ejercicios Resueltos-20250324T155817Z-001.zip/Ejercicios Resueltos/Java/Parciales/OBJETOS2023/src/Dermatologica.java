public class Dermatologica extends EnfermedadCongenita {
    public Dermatologica(String nombre, Integer newAttr) {
        super(nombre, newAttr);
    }
}
