public class Camioneta {
    
}
