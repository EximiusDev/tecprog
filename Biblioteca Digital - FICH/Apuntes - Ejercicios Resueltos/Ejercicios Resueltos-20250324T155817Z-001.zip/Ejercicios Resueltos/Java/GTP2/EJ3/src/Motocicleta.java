public class Motocicleta {
    
}
